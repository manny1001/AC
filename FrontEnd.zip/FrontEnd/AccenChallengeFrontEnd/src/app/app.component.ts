import { Component, OnInit, OnDestroy } from '@angular/core';
import { useMutation, useQuery } from '@apollo/client';
import { Subscription } from 'rxjs';
import { Apollo, gql } from 'apollo-angular';
import { todo } from './todo.gql';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'AccenChallengeFrontEnd';
  todoTitle: string = '';

  Todo: todo = {
    id: 0,
    title: '',
    completed: 0,
    description: '',
  };
  Todos: Observable<todo[]>;
  
  private querySubscription: Subscription;
  GetTodo = gql`
    query Query($getTodoId: Int!) {
      getTodo(id: $getTodoId) {
        completed
        description
        id
        title
      }
    }
  `;
  GetTodos = gql`
    query GetTodos {
      getTodos {
        completed
        description
        id
        title
      }
    }
  `;

  Create_Todo = gql`
    mutation createTodo($title: String!, $description: String!) {
      createTodo(title: $title, description: $description) {
        id
        completed
        description
        title
      }
    }
  `;
  Delete_Todo = gql`
    mutation DeleteTodoMutation($deleteTodoId: Int!) {
      deleteTodo(id: $deleteTodoId) {
        id
        completed
        description
        title
      }
    }
  `;
  constructor(private apollo: Apollo) {}
  ngOnInit() {
    this.refresh();
  }
  ngOnDestroy() {
    this.querySubscription.unsubscribe();
  }

  refresh() {
    this.querySubscription = this.apollo
      .watchQuery<any>({
        query: this.GetTodos,
      })
      .valueChanges.subscribe(({ data, loading }) => {
        return (this.Todos = data.getTodos);
      });
  }
  enterTodo(value: string) {
    this.todoTitle = value;
  }

  CreateTodo() {
    this.apollo
      .mutate({
        mutation: this.Create_Todo,
        variables: {
          title: this.todoTitle,
          description: 'none',
        },
      })
      .subscribe({
        next: (data: any) => {
          console.log(data);
          alert('Todo successfully created');
          this.Todos = data.createTodo;
          return this.Todos;
        },
        error: (error) => {
          alert('There was an error!');
          console.error('There was an error!', error);
        },
      });
  }
  DeleteTodo(id) {
    this.apollo
      .mutate({
        mutation: this.Delete_Todo,
        variables: { deleteTodoId: id },
      })
      .subscribe({
        next: (data: any) => {
          console.log(data.data.deleteTodo);
          this.Todos = data.data.deleteTodos;
          return this.Todos;
        },
        error: (error) => {
          console.error('There was an error!', error);
        },
      }); /* (
        ({ data }) => {
          console.log(data);
          alert('Todo Successfully deleted');
        },
        (error) => {
          alert('there was an error sending the query');
        }
      ); */
  }
}
