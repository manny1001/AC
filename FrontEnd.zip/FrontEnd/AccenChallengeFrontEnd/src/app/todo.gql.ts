export type todo = {
  id: number;
  title: string;
  completed: number;
  description: string;
};
